"use client";

import { useState, useEffect, useRef } from "react";

interface LeadModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface FormData {
  fullName: string;
  workEmail: string;
  companyName: string;
  projectIdea: string;
}

interface FormErrors {
  fullName?: string;
  workEmail?: string;
  companyName?: string;
  projectIdea?: string;
}

export default function LeadModal({ isOpen, onClose }: LeadModalProps) {
  const [formData, setFormData] = useState<FormData>({
    fullName: "",
    workEmail: "",
    companyName: "",
    projectIdea: "",
  });
  const [errors, setErrors] = useState<FormErrors>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const overlayRef = useRef<HTMLDivElement>(null);
  const firstInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) setTimeout(() => firstInputRef.current?.focus(), 100);
  }, [isOpen]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && isOpen) onClose();
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, onClose]);

  useEffect(() => {
    document.body.style.overflow = isOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [isOpen]);

  const validate = (): boolean => {
    const newErrors: FormErrors = {};
    if (!formData.fullName.trim()) newErrors.fullName = "Full name is required.";
    if (!formData.workEmail.trim()) {
      newErrors.workEmail = "Work email is required.";
    } else if (!formData.workEmail.includes("@") || !formData.workEmail.includes(".")) {
      newErrors.workEmail = "Please enter a valid email address.";
    }
    if (!formData.companyName.trim()) newErrors.companyName = "Company name is required.";
    if (!formData.projectIdea.trim()) {
      newErrors.projectIdea = "Please describe your project idea.";
    } else if (formData.projectIdea.trim().length < 20) {
      newErrors.projectIdea = "Please provide at least 20 characters.";
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
    if (errors[name as keyof FormErrors]) setErrors((prev) => ({ ...prev, [name]: undefined }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setIsSubmitting(true);
    await new Promise((resolve) => setTimeout(resolve, 800));
    const lead = {
      name: formData.fullName,
      email: formData.workEmail,
      company: formData.companyName,
      project: formData.projectIdea,
      timestamp: new Date().toISOString(),
    };
    console.log("📋 Lead captured:", lead);
    alert(`✅ Lead captured: ${formData.fullName} – We'll email you within 24 hours.`);
    setFormData({ fullName: "", workEmail: "", companyName: "", projectIdea: "" });
    setErrors({});
    setIsSubmitting(false);
    onClose();
  };

  const handleOverlayClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (e.target === overlayRef.current) onClose();
  };

  if (!isOpen) return null;

  const inputBase =
    "w-full bg-white/[0.04] border rounded-xl pl-9 pr-4 py-3 text-white placeholder-white/20 text-sm outline-none transition-all duration-200 focus:bg-white/[0.06]";
  const inputNormal = "border-white/10 focus:border-red-500/50";
  const inputError  = "border-red-500/50 focus:border-red-500";

  return (
    <div
      ref={overlayRef}
      onClick={handleOverlayClick}
      className="modal-overlay fixed inset-0 z-[100] flex items-center justify-center p-4"
      style={{
        background: "rgba(0,0,0,0.75)",
        backdropFilter: "blur(16px)",
        WebkitBackdropFilter: "blur(16px)",
      }}
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
    >
      <div className="modal-card w-full max-w-lg relative">
        {/* Red gradient border */}
        <div className="gradient-border">
          <div className="gradient-border-inner p-6 sm:p-8">

            {/* Close */}
            <button
              onClick={onClose}
              className="absolute top-4 right-4 w-8 h-8 rounded-full glass border border-white/10 flex items-center justify-center text-white/40 hover:text-white hover:border-white/20 transition-all duration-200 z-10"
              aria-label="Close modal"
            >
              <i className="fa-solid fa-xmark text-sm"></i>
            </button>

            {/* Header */}
            <div className="mb-7">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-red-600 flex items-center justify-center shadow-lg shadow-red-600/30">
                  <i className="fa-solid fa-rocket text-white text-sm"></i>
                </div>
                <div>
                  <h2 id="modal-title" className="text-xl font-bold text-white tracking-tight">
                    Let&apos;s Build Your AI Solution
                  </h2>
                  <p className="text-white/40 text-xs mt-0.5">We respond within 24 hours</p>
                </div>
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} noValidate className="space-y-4">

              {/* Full Name */}
              <div>
                <label htmlFor="fullName" className="block text-sm font-medium text-white/60 mb-1.5">
                  Full Name <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-white/25">
                    <i className="fa-solid fa-user text-xs"></i>
                  </span>
                  <input
                    ref={firstInputRef}
                    type="text" id="fullName" name="fullName"
                    value={formData.fullName} onChange={handleChange}
                    placeholder="Jane Smith"
                    className={`${inputBase} ${errors.fullName ? inputError : inputNormal}`}
                  />
                </div>
                {errors.fullName && (
                  <p className="text-red-400 text-xs mt-1.5 flex items-center gap-1">
                    <i className="fa-solid fa-circle-exclamation text-xs"></i>{errors.fullName}
                  </p>
                )}
              </div>

              {/* Work Email */}
              <div>
                <label htmlFor="workEmail" className="block text-sm font-medium text-white/60 mb-1.5">
                  Work Email <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-white/25">
                    <i className="fa-solid fa-envelope text-xs"></i>
                  </span>
                  <input
                    type="email" id="workEmail" name="workEmail"
                    value={formData.workEmail} onChange={handleChange}
                    placeholder="jane@company.com"
                    className={`${inputBase} ${errors.workEmail ? inputError : inputNormal}`}
                  />
                </div>
                {errors.workEmail && (
                  <p className="text-red-400 text-xs mt-1.5 flex items-center gap-1">
                    <i className="fa-solid fa-circle-exclamation text-xs"></i>{errors.workEmail}
                  </p>
                )}
              </div>

              {/* Company Name */}
              <div>
                <label htmlFor="companyName" className="block text-sm font-medium text-white/60 mb-1.5">
                  Company Name <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-white/25">
                    <i className="fa-solid fa-building text-xs"></i>
                  </span>
                  <input
                    type="text" id="companyName" name="companyName"
                    value={formData.companyName} onChange={handleChange}
                    placeholder="Acme Corp"
                    className={`${inputBase} ${errors.companyName ? inputError : inputNormal}`}
                  />
                </div>
                {errors.companyName && (
                  <p className="text-red-400 text-xs mt-1.5 flex items-center gap-1">
                    <i className="fa-solid fa-circle-exclamation text-xs"></i>{errors.companyName}
                  </p>
                )}
              </div>

              {/* Project Idea */}
              <div>
                <label htmlFor="projectIdea" className="block text-sm font-medium text-white/60 mb-1.5">
                  Project Idea <span className="text-red-500">*</span>
                </label>
                <textarea
                  id="projectIdea" name="projectIdea"
                  value={formData.projectIdea} onChange={handleChange}
                  placeholder="Describe what you want to build with AI..."
                  rows={4}
                  className={`w-full bg-white/[0.04] border rounded-xl px-4 py-3 text-white placeholder-white/20 text-sm outline-none transition-all duration-200 focus:bg-white/[0.06] resize-none ${errors.projectIdea ? inputError : inputNormal}`}
                />
                {errors.projectIdea && (
                  <p className="text-red-400 text-xs mt-1.5 flex items-center gap-1">
                    <i className="fa-solid fa-circle-exclamation text-xs"></i>{errors.projectIdea}
                  </p>
                )}
              </div>

              {/* Submit */}
              <button
                type="submit"
                disabled={isSubmitting}
                className="btn-glow w-full bg-red-600 hover:bg-red-500 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-3.5 rounded-xl transition-all duration-300 flex items-center justify-center gap-2 mt-1"
              >
                {isSubmitting ? (
                  <><i className="fa-solid fa-spinner fa-spin"></i>Sending...</>
                ) : (
                  <>Send Request <i className="fa-solid fa-arrow-right text-xs"></i></>
                )}
              </button>

              <p className="text-center text-xs text-white/25 mt-1">
                <i className="fa-solid fa-lock mr-1"></i>
                Your data is secure. We never share your information.
              </p>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
