"use client";

interface ServicesProps {
  onOpenModal: () => void;
}

const services = [
  {
    icon: "fa-solid fa-robot",
    iconColor: "text-red-500",
    iconBg: "bg-red-500/10 border border-red-500/20",
    title: "Custom AI Agents",
    description:
      "We design and deploy autonomous AI agents that handle complex workflows, make intelligent decisions, and integrate seamlessly into your existing systems.",
    features: [
      "Multi-step reasoning pipelines",
      "Tool-use & function calling",
      "Memory & context management",
      "Human-in-the-loop controls",
    ],
    badge: "Most Popular",
    badgeColor: "bg-red-500/10 text-red-400 border border-red-500/20",
  },
  {
    icon: "fa-solid fa-brain",
    iconColor: "text-orange-400",
    iconBg: "bg-orange-500/10 border border-orange-500/20",
    title: "LLM Integration",
    description:
      "Seamlessly integrate GPT-4, Claude, Gemini, and open-source models into your product. We handle fine-tuning, prompt engineering, and production deployment.",
    features: [
      "GPT-4o, Claude 3.5, Gemini 1.5",
      "RAG & vector databases",
      "Fine-tuning & RLHF",
      "Cost optimization strategies",
    ],
    badge: "Enterprise Ready",
    badgeColor: "bg-orange-500/10 text-orange-400 border border-orange-500/20",
  },
  {
    icon: "fa-solid fa-chart-line",
    iconColor: "text-rose-400",
    iconBg: "bg-rose-500/10 border border-rose-500/20",
    title: "AI-Powered Analytics",
    description:
      "Transform raw data into actionable intelligence with predictive models, anomaly detection, and real-time dashboards powered by machine learning.",
    features: [
      "Predictive modeling & forecasting",
      "Anomaly detection systems",
      "Real-time ML pipelines",
      "Custom BI dashboards",
    ],
    badge: "Data-Driven",
    badgeColor: "bg-rose-500/10 text-rose-400 border border-rose-500/20",
  },
];

export default function Services({ onOpenModal }: ServicesProps) {
  return (
    <section id="services" className="py-28 relative bg-[#0a0a0a]">
      {/* Subtle red glow top */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[1px] red-line" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 glass border border-white/8 rounded-full px-4 py-2 mb-5">
            <i className="fa-solid fa-bolt text-red-500 text-xs"></i>
            <span className="text-sm text-white/50 font-medium tracking-wide">What We Build</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white mb-4 tracking-tight">
            Our <span className="gradient-text">Core Services</span>
          </h2>
          <p className="text-white/40 text-lg max-w-2xl mx-auto font-light">
            End-to-end AI development from architecture to deployment. We own
            the full stack so you can focus on your business.
          </p>
        </div>

        {/* Service cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5 lg:gap-6">
          {services.map((service) => (
            <div
              key={service.title}
              className="card-hover glass-card rounded-2xl p-7 lg:p-8 flex flex-col group border border-white/[0.06]"
            >
              {/* Icon + Badge row */}
              <div className="flex items-start justify-between mb-6">
                <div className={`w-12 h-12 rounded-xl ${service.iconBg} flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                  <i className={`${service.icon} ${service.iconColor} text-lg`}></i>
                </div>
                <span className={`text-xs font-semibold px-3 py-1 rounded-full ${service.badgeColor}`}>
                  {service.badge}
                </span>
              </div>

              {/* Content */}
              <h3 className="text-lg font-bold text-white mb-3 tracking-tight">{service.title}</h3>
              <p className="text-white/40 text-sm leading-relaxed mb-6 flex-grow font-light">
                {service.description}
              </p>

              {/* Features */}
              <ul className="space-y-2.5 mb-8">
                {service.features.map((feature) => (
                  <li key={feature} className="flex items-center gap-2.5 text-sm text-white/60">
                    <i className="fa-solid fa-check text-red-500 text-xs flex-shrink-0"></i>
                    {feature}
                  </li>
                ))}
              </ul>

              {/* CTA */}
              <button
                onClick={onOpenModal}
                className="w-full glass border border-white/8 hover:border-red-500/40 hover:bg-red-500/5 text-white font-semibold py-3 rounded-xl transition-all duration-300 text-sm flex items-center justify-center gap-2"
              >
                Get Quote
                <i className="fa-solid fa-arrow-right text-red-500 text-xs group-hover:translate-x-1 transition-transform duration-300"></i>
              </button>
            </div>
          ))}
        </div>

        {/* Bottom CTA */}
        <div className="mt-16 text-center">
          <p className="text-white/30 mb-5 text-sm">Need something custom? We build bespoke AI solutions too.</p>
          <button
            onClick={onOpenModal}
            className="btn-glow bg-red-600 hover:bg-red-500 text-white font-bold px-8 py-4 rounded-full transition-all duration-300 inline-flex items-center gap-2.5 text-sm"
          >
            Deploy an AI Team
            <i className="fa-solid fa-arrow-right text-xs"></i>
          </button>
        </div>
      </div>

      {/* Subtle red glow bottom */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[800px] h-[1px] red-line" />
    </section>
  );
}
