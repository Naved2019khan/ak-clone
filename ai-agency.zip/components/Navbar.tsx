"use client";

import { useState, useEffect } from "react";

interface NavbarProps {
  onOpenModal: () => void;
}

export default function Navbar({ onOpenModal }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled ? "glass-dark shadow-xl shadow-black/40" : "bg-transparent"
      }`}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-red-600 flex items-center justify-center shadow-lg shadow-red-600/30">
              <i className="fa-solid fa-robot text-white text-sm"></i>
            </div>
            <span className="font-bold text-lg text-white tracking-tight">
              AI<span className="gradient-text">Dev</span>Agency
            </span>
          </div>

          {/* Desktop Nav */}
          <div className="hidden md:flex items-center gap-8">
            {["#services", "#case-studies", "#"].map((href, i) => (
              <a
                key={href}
                href={href}
                className="text-white/60 hover:text-white transition-colors text-sm font-medium"
              >
                {["Services", "Case Studies", "Blog"][i]}
              </a>
            ))}
            <button
              onClick={onOpenModal}
              className="btn-glow bg-red-600 hover:bg-red-500 text-white text-sm font-semibold px-5 py-2 rounded-full transition-all duration-300"
            >
              Get Quote
            </button>
          </div>

          {/* Mobile menu button */}
          <button
            className="md:hidden text-white/60 hover:text-white"
            onClick={() => setMenuOpen(!menuOpen)}
            aria-label="Toggle menu"
          >
            <i className={`fa-solid ${menuOpen ? "fa-xmark" : "fa-bars"} text-xl`}></i>
          </button>
        </div>

        {/* Mobile Menu */}
        {menuOpen && (
          <div className="md:hidden glass-dark rounded-2xl mt-2 mb-4 p-5 flex flex-col gap-4">
            {["#services", "#case-studies", "#"].map((href, i) => (
              <a
                key={href}
                href={href}
                className="text-white/60 hover:text-white transition-colors text-sm font-medium"
                onClick={() => setMenuOpen(false)}
              >
                {["Services", "Case Studies", "Blog"][i]}
              </a>
            ))}
            <button
              onClick={() => { setMenuOpen(false); onOpenModal(); }}
              className="btn-glow bg-red-600 hover:bg-red-500 text-white text-sm font-semibold px-5 py-2.5 rounded-full w-full"
            >
              Get Quote
            </button>
          </div>
        )}
      </div>
    </nav>
  );
}
