"use client";

interface HeroProps {
  onOpenModal: () => void;
}

export default function Hero({ onOpenModal }: HeroProps) {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">

      {/* Background — deep black with red orbs */}
      <div className="absolute inset-0 bg-[#0a0a0a]" />

      {/* Red glow orbs */}
      <div className="orb w-[600px] h-[600px] bg-red-600 -top-32 -left-40" style={{ position: "absolute" }} />
      <div className="orb w-[500px] h-[500px] bg-red-700 bottom-0 -right-32" style={{ position: "absolute" }} />
      <div className="orb w-[300px] h-[300px] bg-orange-600 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" style={{ position: "absolute" }} />

      {/* Subtle grid */}
      <div
        className="absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage: `linear-gradient(rgba(255,255,255,0.6) 1px, transparent 1px),
            linear-gradient(90deg, rgba(255,255,255,0.6) 1px, transparent 1px)`,
          backgroundSize: "64px 64px",
        }}
      />

      {/* Radial vignette */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_40%,#0a0a0a_100%)]" />

      <div className="relative z-10 max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center">

        {/* Live badge */}
        <div className="hero-animate inline-flex items-center gap-2 glass border border-white/10 rounded-full px-4 py-2 mb-8">
          <span className="pulse-dot w-2 h-2 rounded-full bg-red-500 inline-block"></span>
          <span className="text-sm text-white/60 font-medium">
            Now accepting new clients for Q3 2026
          </span>
        </div>

        {/* Headline */}
        <h1 className="hero-animate-delay-1 text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-black text-white leading-[1.08] tracking-tight mb-6">
          Build Smarter with{" "}
          <span className="gradient-text">AI-Native</span>
          <br />
          Software Engineers
        </h1>

        {/* Subheadline */}
        <p className="hero-animate-delay-2 text-lg sm:text-xl text-white/50 max-w-2xl mx-auto mb-10 leading-relaxed font-light">
          We build custom AI agents, LLM integrations, and intelligent
          automation for forward-thinking companies.
        </p>

        {/* CTA Buttons */}
        <div className="hero-animate-delay-3 flex flex-col sm:flex-row items-center justify-center gap-4">
          <button
            onClick={onOpenModal}
            className="btn-glow bg-red-600 hover:bg-red-500 text-white font-bold px-8 py-4 rounded-full text-base transition-all duration-300 flex items-center gap-2.5 w-full sm:w-auto justify-center"
          >
            Deploy an AI Team
            <i className="fa-solid fa-arrow-right text-sm"></i>
          </button>
          <a
            href="#case-studies"
            className="glass border border-white/10 hover:border-white/20 hover:bg-white/5 text-white font-semibold px-8 py-4 rounded-full text-base transition-all duration-300 flex items-center gap-2.5 w-full sm:w-auto justify-center"
          >
            <i className="fa-solid fa-play text-red-500 text-xs"></i>
            See Case Studies
          </a>
        </div>

        {/* Stats */}
        <div className="hero-animate-delay-3 mt-20 grid grid-cols-3 gap-4 sm:gap-10 max-w-xl mx-auto">
          {[
            { value: "50+", label: "AI Projects Shipped" },
            { value: "98%", label: "Client Satisfaction" },
            { value: "24h", label: "Response Time" },
          ].map((stat) => (
            <div key={stat.label} className="text-center">
              <div className="text-2xl sm:text-3xl font-black gradient-text">{stat.value}</div>
              <div className="text-xs sm:text-sm text-white/40 mt-1 font-medium">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 text-white/30">
        <span className="text-xs tracking-widest uppercase">Scroll</span>
        <div className="w-5 h-8 rounded-full border border-white/20 flex items-start justify-center p-1">
          <div
            className="w-1 h-2 bg-red-500 rounded-full"
            style={{ animation: "scrollDot 1.5s ease-in-out infinite" }}
          />
        </div>
      </div>

      <style jsx>{`
        @keyframes scrollDot {
          0% { transform: translateY(0); opacity: 1; }
          100% { transform: translateY(12px); opacity: 0; }
        }
      `}</style>
    </section>
  );
}
