"use client";

export default function Footer() {
  return (
    <footer className="relative bg-[#080808] border-t border-white/[0.05] pt-16 pb-8">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[600px] h-[1px] red-line" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10 mb-14">

          {/* Col 1 – Brand */}
          <div className="sm:col-span-2 lg:col-span-1">
            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-8 h-8 rounded-lg bg-red-600 flex items-center justify-center shadow-lg shadow-red-600/30">
                <i className="fa-solid fa-robot text-white text-sm"></i>
              </div>
              <span className="font-bold text-base text-white tracking-tight">
                AI<span className="gradient-text">Dev</span>Agency
              </span>
            </div>
            <p className="text-white/35 text-sm leading-relaxed mb-5 font-light">
              AI development agency building enterprise-grade solutions. From
              concept to production, we ship AI that works.
            </p>
            <div className="flex items-center gap-2.5">
              {[
                { icon: "fa-brands fa-x-twitter", label: "Twitter" },
                { icon: "fa-brands fa-linkedin-in", label: "LinkedIn" },
                { icon: "fa-brands fa-github", label: "GitHub" },
                { icon: "fa-brands fa-youtube", label: "YouTube" },
              ].map((s) => (
                <a
                  key={s.label}
                  href="#"
                  aria-label={s.label}
                  className="w-8 h-8 rounded-lg glass border border-white/[0.06] flex items-center justify-center text-white/35 hover:text-white hover:border-red-500/30 transition-all duration-200"
                >
                  <i className={`${s.icon} text-xs`}></i>
                </a>
              ))}
            </div>
          </div>

          {/* Col 2 – Links */}
          <div>
            <h4 className="text-white/80 font-semibold text-sm mb-5 flex items-center gap-2">
              <i className="fa-solid fa-link text-red-500 text-xs"></i>
              Links
            </h4>
            <ul className="space-y-3">
              {[
                { label: "Services",     href: "#services" },
                { label: "Case Studies", href: "#case-studies" },
                { label: "Blog",         href: "#" },
                { label: "Careers",      href: "#" },
              ].map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-white/35 hover:text-white text-sm transition-colors duration-200 flex items-center gap-2 group"
                  >
                    <i className="fa-solid fa-chevron-right text-xs text-red-600 opacity-0 group-hover:opacity-100 transition-opacity duration-200"></i>
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 3 – Legal */}
          <div>
            <h4 className="text-white/80 font-semibold text-sm mb-5 flex items-center gap-2">
              <i className="fa-solid fa-scale-balanced text-red-500 text-xs"></i>
              Legal
            </h4>
            <ul className="space-y-3">
              {[
                { label: "Privacy Policy",   href: "#" },
                { label: "Terms of Service", href: "#" },
                { label: "Cookie Policy",    href: "#" },
                { label: "GDPR",             href: "#" },
              ].map((link) => (
                <li key={link.label}>
                  <a
                    href={link.href}
                    className="text-white/35 hover:text-white text-sm transition-colors duration-200 flex items-center gap-2 group"
                  >
                    <i className="fa-solid fa-chevron-right text-xs text-red-600 opacity-0 group-hover:opacity-100 transition-opacity duration-200"></i>
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Col 4 – Contact */}
          <div>
            <h4 className="text-white/80 font-semibold text-sm mb-5 flex items-center gap-2">
              <i className="fa-solid fa-headset text-red-500 text-xs"></i>
              Contact
            </h4>
            <ul className="space-y-3">
              <li>
                <a href="mailto:hello@aiagency.dev" className="text-white/35 hover:text-white text-sm transition-colors duration-200 flex items-center gap-2">
                  <i className="fa-solid fa-envelope text-red-500 text-xs w-4"></i>
                  hello@aiagency.dev
                </a>
              </li>
              <li>
                <a href="tel:+15552223333" className="text-white/35 hover:text-white text-sm transition-colors duration-200 flex items-center gap-2">
                  <i className="fa-solid fa-phone text-red-500 text-xs w-4"></i>
                  +1 (555) 222-3333
                </a>
              </li>
              <li className="flex items-start gap-2 text-white/35 text-sm">
                <i className="fa-solid fa-location-dot text-red-500 text-xs w-4 mt-0.5"></i>
                <span>100 AI Boulevard<br />San Francisco, CA 94105</span>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-white/[0.05] pt-7 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-white/25 text-sm">© 2026 AI Dev Agency. All rights reserved.</p>
          <div className="flex items-center gap-1 text-white/20 text-xs">
            <span>Built with</span>
            <i className="fa-solid fa-heart text-red-600 mx-1 text-xs"></i>
            <span>and</span>
            <i className="fa-solid fa-robot text-red-500 mx-1 text-xs"></i>
            <span>by AI Dev Agency</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
