"use client";

const logos = [
  { name: "NexusAI",     icon: "fa-solid fa-hexagon-nodes", color: "text-red-400" },
  { name: "FutureSoft",  icon: "fa-solid fa-microchip",     color: "text-orange-400" },
  { name: "DataViz",     icon: "fa-solid fa-chart-pie",     color: "text-rose-400" },
  { name: "QuantumLabs", icon: "fa-solid fa-atom",          color: "text-red-300" },
  { name: "SynthCore",   icon: "fa-solid fa-code-branch",   color: "text-orange-300" },
];

const testimonials = [
  {
    quote:
      "The AI agent they built reduced our customer support ticket volume by 68% in the first month. The team was fast, communicative, and delivered exactly what we needed.",
    author: "Sarah Chen",
    role: "CTO, NexusAI",
    avatar: "SC",
    avatarBg: "bg-red-600",
    stars: 5,
  },
  {
    quote:
      "We integrated GPT-4 into our analytics platform in under 3 weeks. The LLM integration was seamless and the performance optimizations saved us 40% on API costs.",
    author: "Marcus Rivera",
    role: "VP Engineering, DataViz",
    avatar: "MR",
    avatarBg: "bg-orange-600",
    stars: 5,
  },
];

export default function CaseStudies() {
  return (
    <section id="case-studies" className="py-28 relative bg-[#0d0d0d]">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[1px] red-line" />

      {/* Faint red orb */}
      <div className="orb w-[500px] h-[500px] bg-red-700 top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2" style={{ position: "absolute", opacity: 0.06 }} />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">

        {/* Section header */}
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 glass border border-white/8 rounded-full px-4 py-2 mb-5">
            <i className="fa-solid fa-shield-check text-red-500 text-xs"></i>
            <span className="text-sm text-white/50 font-medium tracking-wide">Social Proof</span>
          </div>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-black text-white mb-4 tracking-tight">
            Trusted by{" "}
            <span className="gradient-text">AI-First Companies</span>
          </h2>
          <p className="text-white/40 text-lg max-w-2xl mx-auto font-light">
            From early-stage startups to enterprise teams, we&apos;ve helped
            companies ship AI products that actually work.
          </p>
        </div>

        {/* Logo strip */}
        <div className="flex flex-wrap items-center justify-center gap-4 sm:gap-6 mb-20">
          {logos.map((logo) => (
            <div
              key={logo.name}
              className="card-hover glass-card border border-white/[0.06] rounded-2xl px-5 py-3.5 flex items-center gap-3 cursor-default"
            >
              <div className="w-8 h-8 rounded-lg bg-white/5 flex items-center justify-center">
                <i className={`${logo.icon} ${logo.color} text-sm`}></i>
              </div>
              <span className="text-white/60 font-semibold text-sm">{logo.name}</span>
            </div>
          ))}
        </div>

        {/* Testimonials */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5 lg:gap-6">
          {testimonials.map((t) => (
            <div
              key={t.author}
              className="card-hover glass-card border border-white/[0.06] rounded-2xl p-7 lg:p-8 relative overflow-hidden"
            >
              {/* Big quote mark */}
              <div className="absolute top-3 right-6 text-7xl text-white/[0.03] font-serif leading-none select-none pointer-events-none">
                &ldquo;
              </div>

              {/* Stars */}
              <div className="flex gap-1 mb-5">
                {Array.from({ length: t.stars }).map((_, i) => (
                  <i key={i} className="fa-solid fa-star text-red-500 text-xs"></i>
                ))}
              </div>

              {/* Quote */}
              <p className="text-white/60 text-base leading-relaxed mb-6 relative z-10 font-light">
                &ldquo;{t.quote}&rdquo;
              </p>

              {/* Author */}
              <div className="flex items-center gap-3">
                <div className={`w-9 h-9 rounded-full ${t.avatarBg} flex items-center justify-center text-white text-xs font-bold flex-shrink-0`}>
                  {t.avatar}
                </div>
                <div>
                  <div className="text-white font-semibold text-sm">{t.author}</div>
                  <div className="text-white/40 text-xs">{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Metrics */}
        <div className="mt-12 glass-card border border-white/[0.06] rounded-2xl p-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            {[
              { value: "$12M+", label: "Client Revenue Generated", icon: "fa-solid fa-dollar-sign" },
              { value: "50+",   label: "AI Projects Delivered",    icon: "fa-solid fa-rocket" },
              { value: "15+",   label: "Industries Served",        icon: "fa-solid fa-building" },
              { value: "4.9/5", label: "Average Client Rating",    icon: "fa-solid fa-star" },
            ].map((metric) => (
              <div key={metric.label} className="flex flex-col items-center gap-2">
                <div className="w-9 h-9 rounded-xl bg-red-500/10 border border-red-500/20 flex items-center justify-center mb-1">
                  <i className={`${metric.icon} text-red-500 text-sm`}></i>
                </div>
                <div className="text-2xl sm:text-3xl font-black gradient-text">{metric.value}</div>
                <div className="text-xs text-white/40 text-center font-medium">{metric.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[800px] h-[1px] red-line" />
    </section>
  );
}
